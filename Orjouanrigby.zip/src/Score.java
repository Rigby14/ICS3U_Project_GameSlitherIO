
public class Score {

}
